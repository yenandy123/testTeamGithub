package com.example.idonnow

class Person {
    var name=""
    var pwd=""
}